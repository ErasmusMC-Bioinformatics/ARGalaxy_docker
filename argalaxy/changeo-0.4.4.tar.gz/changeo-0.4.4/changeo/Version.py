"""
Version and authorship information
"""

__author__    = 'Namita Gupta, Jason Anthony Vander Heiden'
__copyright__ = 'Copyright 2017 Kleinstein Lab, Yale University. All rights reserved.'
__license__   = 'Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)'
__version__   = '0.4.4'
__date__      = '2018.10.27'
